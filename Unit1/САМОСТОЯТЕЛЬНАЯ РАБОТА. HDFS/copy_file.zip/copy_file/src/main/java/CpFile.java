import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileUtil;
public class CpFile {
    public static void main(String[] args) throws Exception {
        Path path_src = new Path(args[0]);
        Path path_dest = new Path(args[1]);
        Configuration conf = new Configuration();
        FileUtil.copy(path_src.getFileSystem(conf), path_src,
                path_dest.getFileSystem(conf), path_dest,
                false, conf);
    }
}
