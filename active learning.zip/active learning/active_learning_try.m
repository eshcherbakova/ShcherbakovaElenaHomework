%url = 'http://185.86.147.95/oracle?x1=10&x2=10&x3=10&x4=10&x5=10&x6=10&x7=10&x8=10&x9=10&x10=0.2';
%data = webread(url)

pattern1 = 'Function value = ';% start of list
pattern2 = 'Attempts left =';     % end of list
list = extractBetween(data, pattern1, pattern2);                % extract list

X = str2double(list{1})

sprintf('%.10f', X)
%% 

str1 = ["x1=";"x2=";"x3="];
str2 = string([1; 2; 3]);
%str3 = ["&"; "&"; ""];
%str = strcat(str1,str2, str3)
str = strcat(str1,str2)
str = strjoin(str,"&") 

%% 
ind = zeros(10, 1) + 1;
 
 
nam = 11;
url = 'http://185.86.147.95/oracle?';
str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
coord = (ind - 1).*10./(nam - 1);
str = strcat(str1, string(coord));
str = strjoin(str,"&");
url = strcat(url, str)

%data = webread(url)

% pattern1 = 'Function value = ';% start of list
% pattern2 = 'Attempts left =';     % end of list
% list = extractBetween(data, pattern1, pattern2);                % extract list
% 
% [X,tf] = str2num(list{1})


%% 
coord = zeros(10, 1) + 10;
coord(10) = 0.2
filename = '/Users/lmac/Documents/MATLAB/f_val.txt';
fileID = fopen(filename, 'a+');

fprintf(fileID, strcat(repmat('%f ', [1 10]), ' %.10f\n'), [coord; X]');

fclose(fileID);
%% 
url = 'http://185.86.147.95/oracle?';
str = strcat(str1, string(coord));
str = strjoin(str,"&"); 
url = strcat(url, str)
%% 

ind = zeros(10, 1) + 11;
elem = bb_fun_elem(ind)
 
%% 
eps = 0.5e-1;
fun = @bb_fun_elem;
st = zeros(1, 10) + 11;

[y]=amen_cross(st, fun, eps)
%% 

for i = 3:9
    nam = 11;
    url = 'http://185.86.147.95/oracle?';
    str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
    coord = zeros(10, 1) + 10;
    coord(i) = 0.2;
    str = strcat(str1, string(coord));
    str = strjoin(str,"&");
    url = strcat(url, str);
    data = webread(url);
    display(coord')
    display(url)
    display(data)
    pattern1 = 'Function value = ';% start of list
    pattern2 = 'Attempts left =';  % end of list
    list = extractBetween(data, pattern1, pattern2);% extract list

    fun_value = str2double(list{1});
    
    filename = '/Users/lmac/Documents/MATLAB/f_val.txt';
    fileID = fopen(filename, 'a+');
    fprintf(fileID, strcat(repmat('%f ', [1 10]), ' %.10f\n'), [coord; fun_value]');
    fclose(fileID);

end

%% 



    nam = 11;
    url = 'http://185.86.147.95/oracle?';
    str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
    coord = zeros(10, 1) + exp(2);
%     coord(6) = 1;
%     coord(10) = 1;
%     coord(7) = 1;
%     coord(5) = 0;
% 
    coord(3) = exp(1);
% 
%     coord(4) = 1.570800;
%     coord(8) = 4;
%     coord(9) = 5;

%     coord(9) = 1;
    str = strcat(str1, string(coord));
    str = strjoin(str,"&");
    url = strcat(url, str);
    data = webread(url);
    display(coord')
    display(url)
    display(data)
    pattern1 = 'Function value = ';% start of list
    pattern2 = 'Attempts left =';  % end of list
    list = extractBetween(data, pattern1, pattern2);% extract list

    fun_value = str2double(list{1});
    
    filename = '/Users/lmac/Documents/MATLAB/f_val.txt';
    fileID = fopen(filename, 'a+');
    fprintf(fileID, strcat(repmat('%f ', [1 10]), ' %.10f\n'), [coord; fun_value]');
    fclose(fileID);


    %% 
    
    
(-3.4892648053 - 1.4201854788) 
%% 
    
(-69.1402763052 + 21.6775978432)     
    %% 

(exp(2) - exp(1))*log(10)*(-0.2325425028)
%% 
sprintf('%.10f', -95.0592649961 - -92.7338399684)


%% 
sprintf('%.10f', (2.6672913255 - 2.8998338283)*10)
%% 
-97.8892084137 - -96.2083074423
%% 
close all
y = [1.85081571768 3.5319568464 4.23307061676 5.35385209628 6.01573640782 6.3528651677]
y = y - 1.85081571768;
x = [0 1 2 5 8 10]

plot(x, y)
%% 

exp(2.36787944117)*exp(0.5)




2.97235060424 - 2.36787944117
%% 
close all

x = [1 exp(0.5) exp(1) exp(1.5) exp(2)]
%x = [1 1.6487 2.7183 7.3891]
y = [2.3678794412 2.9723506042 3.6065393719 4.27880417145 5.00000891202]
y = y - log(x)
plot(x, y)
%% 

close all

x = [0 2 4 5 6 8 10]
%x = [1 1.6487 2.7183 7.3891]
y = [1.0 -2.40299796172 -1.52988565647 3.52532008582 1.0414819266 -6.87285063669 -1.19179350669]
y = y - 1;
plot(x, y)


%% 

-95.4126097877 - -95.7055030065
%% 

32.6227766017 / 4.16227766017

%% 

-95.4126097877 - -95.5570238517

%% 

log(10 + exp(1)*10) - log(10 + exp(1)*5)

%% 

log(exp(1)*10) - log(exp(1)*5)
%% 

22.733568188 - 22.0404210074

%% 

-77.1500799846 - -76.4834133179


%% 
-76.9278577624 - -76.4834133179
%% 
1 - 5/9
%% 
-76.4834133179 - -76.8167466513
%% 

-76.4834133179 - -74.4834133179
%% 

-76.4834133179 - -2.48341331794
%% 
-76.4834133179 - -4.48341331794 
%%
close all
x = [exp(1)/pi 1 exp(0.2) exp(0.5) exp(1) exp(1.2) exp(1.5) exp(1.8) exp(2)]
y = [2.19747383617 2.36787944117 2.60656694249 2.97235060424 3.60653937193 3.87031324067 4.27880417145 4.70482602259 5.00000891202]
plot(x, y)
%% 
x .^ 0.5
y
%% 

1.36787944117 + log(x) + sqrt(x)/2

log(4*x) + x .^ 0.25
log(exp(2) / 2 .*x) + x .^ 0.25
y
%% 

x = 10
log(4*x) + x .^ 0.25
log(exp(2) / 2 .*x) + x .^ 0.25

log(3.9271 .*x) + x .^ 0.25

5.46592203145
%% 

3.21869515885

1.85081571768 - 1 + 2.36787944117
%% 
for x3 = 0.125:0.126:10
   for x4 = 0.125:0.126:10
      for x5 = 0.125:0.126:10

    url = 'http://185.86.147.95/oracle?';
    str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
    coord = zeros(10, 1) + 10;
    coord(3) = x3;
    coord(4) = x4;
    coord(5) = x5;

    str = strcat(str1, string(coord));
    str = strjoin(str,"&");
    url = strcat(url, str);
    data = webread(url);
%     display(coord')
%     display(url)
%     display(data)
    pattern1 = 'Function value = ';% start of list
    pattern2 = 'Attempts left =';  % end of list
    list = extractBetween(data, pattern1, pattern2);% extract list

    fun_value = str2double(list{1});
    
    filename = '/Users/lmac/Documents/MATLAB/f_val.txt';
    fileID = fopen(filename, 'a+');
    fprintf(fileID, strcat(repmat('%f ', [1 10]), ' %.10f\n'), [coord; fun_value]');
    fclose(fileID);
      end
   end
end

%% 

filename = '/Users/lmac/Documents/MATLAB/f_val.txt';
fileID = fopen(filename, 'a+');
i = 1;

for x3 = 5.1650:0.126:10
   for x4 = 9.7010:0.126:10
      for x5 = 3.7790:0.126:5

    url = 'http://185.86.147.95/oracle?';
    str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
    coord = zeros(10, 1) + 10;
    coord(3) = x3;
    coord(4) = x4;
    coord(5) = x5;

    str = strcat(str1, string(coord));
    str = strjoin(str,"&");
    url = strcat(url, str);
    data = webread(url);
%     display(coord')
%     display(url)
%     display(data)
    pattern1 = 'Function value = ';% start of list
    pattern2 = 'Attempts left =';  % end of list
    list = extractBetween(data, pattern1, pattern2);% extract list

    fun_value = str2double(list{1});
    
    fprintf(fileID, strcat(repmat('%f ', [1 10]), ' %.10f\n'), [coord; fun_value]');
    i = i + 1;
    
    if mod(i, 100) == 0
        disp(i);
    end
    
      end
   end
end

fclose(fileID);
disp('Done');
%% 

filename = '/Users/lmac/Documents/MATLAB/f_x4_val.txt';
fileID = fopen(filename, 'a+');
i = 1;
f_list = [];

for x4 = 0:0.0001:10

    url = 'http://185.86.147.95/oracle?';
    str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
    coord = zeros(10, 1) + 0;
    coord(7) = 1;
    coord(10) = 1;
    coord(4) = x4;
    coord(5) = 1;

    str = strcat(str1, string(coord));
    str = strjoin(str,"&");
    url = strcat(url, str);
    data = webread(url);
%     display(coord')
%     display(url)
%     display(data)
    pattern1 = 'Function value = ';% start of list
    pattern2 = 'Attempts left =';  % end of list
    list = extractBetween(data, pattern1, pattern2);% extract list

    fun_value = str2double(list{1});
    
    fprintf(fileID, strcat(repmat('%f ', [1 10]), ' %.10f\n'), [coord; fun_value]');
    i = i + 1;
    f_list = [f_list fun_value];
    if mod(i, 100) == 0
        disp(i);
    end
    
end

fclose(fileID);
disp('Done');

%% 
close all
plot(0:0.0001:10, f_list - 1)

%% 

-65.4396272174 - -56.7159608631

-11.8237907773 - -3.10012442296
%% 

-42.7543404367 - -43.9377699277
%% 

-12.6106579936 - -13.7940874846


%% 

filename = '/Users/lmac/Documents/MATLAB/f_x4_val_loupe.txt';
fileID = fopen(filename, 'a+');
i = 1;
f_list = [];

for x4 = 4.69:1e-5:4.73

    url = 'http://185.86.147.95/oracle?';
    str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
    coord = zeros(10, 1) + 0;
    coord(7) = 1;
    coord(10) = 1;
    coord(4) = x4;
    coord(5) = 1;

    str = strcat(str1, string(coord));
    str = strjoin(str,"&");
    url = strcat(url, str);
    data = webread(url);
%     display(coord')
%     display(url)
%     display(data)
    pattern1 = 'Function value = ';% start of list
    pattern2 = 'Attempts left =';  % end of list
    list = extractBetween(data, pattern1, pattern2);% extract list

    fun_value = str2double(list{1});
    
    fprintf(fileID, strcat(repmat('%f ', [1 10]), ' %.10f\n'), [coord; fun_value]');
    i = i + 1;
    f_list = [f_list fun_value];
    if mod(i, 100) == 0
        disp(i);
    end
    
end

fclose(fileID);
disp('Done');

%% 

filename = '/Users/lmac/Documents/MATLAB/f_x4_val_loupe2.txt';
fileID = fopen(filename, 'a+');
k = 1;
f_list = [];

for x4 = 7.84:1e-6:7.88

    url = 'http://185.86.147.95/oracle?';
    str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
    coord = zeros(10, 1) + 0;
    coord(7) = 1;
    coord(10) = 1;
    coord(4) = x4;
    coord(5) = 1;
    coord_str = [];
    for i = 1:10
        coord_str = [coord_str; sprintf('%0.6f', coord(i))];
    end
    str = strcat(str1, string(coord_str));
    str = strjoin(str,"&");
    url = strcat(url, str);
    data = webread(url);
%     display(coord')
%     display(url)
%     display(data)
    pattern1 = 'Function value = ';% start of list
    pattern2 = 'Attempts left =';  % end of list
    list = extractBetween(data, pattern1, pattern2);% extract list

    fun_value = str2double(list{1});
    
    fprintf(fileID, strcat(repmat('%f ', [1 10]), ' %.10f\n'), [coord; fun_value]');
    k = k + 1;
    f_list = [f_list fun_value];
    if mod(k, 100) == 0
        disp(k);
    end
    
end

fclose(fileID);
disp('Done');

%% 

    coord_str = [];
    for i = 1:10
        coord_str = [coord_str; sprintf('%0.6f', coord(i))];
    end

coord_str

%% 

log(exp(4) + exp(3)) + 1 -log(exp(3) + exp(3)) - 1 / sqrt(exp(1))

-47.0549636779 - -48.0685480967

%% 

clear
fid = fopen('/Users/lmac/Downloads/points');

%% 

% Read all lines & collect in cell array
txt = textscan(fid,'%s','delimiter','\n'); 
% Convert string to numerical value
Val = str2double(txt{1}); 

%% 

M = dlmread('/Users/lmac/Downloads/points','');
%% 

X4 = dlmread('/Users/lmac/Documents/MATLAB/f_x4_val.txt','');
%% 

resX4 = X4(:, [4, 11]);

X4 = dlmread('/Users/lmac/Documents/MATLAB/f_x4_val_loupe2.txt','');

resX4 = [resX4; X4(:, [4, 11])];
%% 

u = abs(resX4(:, 1) - M(1, 4));
[minu, minind] = min(u)
%% 
filename = '/Users/lmac/Documents/MATLAB/f_val_test.txt';
fileID = fopen(filename, 'a+');
    
for i = 1620:size(M, 1)
    url = 'http://185.86.147.95/oracle?';
    str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
    coord = M(i, :)';

    str = strcat(str1, string(coord));
    str = strjoin(str,"&");
    url = strcat(url, str);
    data = webread(url);
%     display(coord')
%     display(url)
%     display(data)
    pattern1 = 'Function value = ';% start of list
    pattern2 = 'Attempts left =';  % end of list
    list = extractBetween(data, pattern1, pattern2);% extract list

    fun_value = str2double(list{1});
    

    fprintf(fileID, strcat(repmat('%f ', [1 10]), ' %.10f\n'), [coord; fun_value]');
    
    if mod(i, 100) == 0
        disp(i);
    end
end

    fclose(fileID);

    %% 
fval_test = dlmread('/Users/lmac/Documents/MATLAB/f_val_test.txt','');
%% 

f_approx = zeros(size(fval_test, 1), 1);
for i = 1:size(fval_test, 1)
    u = abs(resX4(:, 1) - str2num(string(fval_test(i, 4))));
    [minu, minind] = min(u);
    f_approx(i) = resX4(minind, 2) - 1;

%     f_approx(i) = resX4(resX4(:, 1) == str2num(string(fval_test(i, 4))), 2) - 1;

end
%% 

f_approx = f_approx - fval_test(:, 2) .* fval_test(:, 7);
f_approx = f_approx + (fval_test(:, 9) .* sqrt(fval_test(:, 8)))./ (fval_test(:, 10) .* sqrt(fval_test(:, 7)));
f_approx = f_approx + log(exp(2) .* fval_test(:, 3) + exp(1) .* fval_test(:, 5));
f_approx = f_approx + 1/exp(1) .* sqrt(fval_test(:, 3));

%% 

diff_f = fval_test(:, 11) - f_approx;

[res, n] = sumsqr(diff_f)
%% 

max_diff = diff_f(abs(diff_f) > 1e-3);
max_diff = sort(abs(max_diff));
%% 

max_error_ind = find(abs(diff_f) == max(abs(diff_f)));

max_error_row = fval_test(max_error_ind, :)

%% 

test_row = [8.401877, 3.943829, 7.830992, 7.9844  , 9.116474, 1.975514, ...
       3.352228, 7.682296, 2.777747, 5.5397  ];
% test_row = max_error_row;
test_row_approx = 0;
test_row_approx = test_row_approx - test_row(:, 2) .* test_row(:, 7);
test_row_approx = test_row_approx + (test_row(:, 9) .* sqrt(test_row(:, 8)))./ (test_row(:, 10) .* sqrt(test_row(:, 7)));
test_row_approx = test_row_approx + log(exp(2) .* test_row(:, 3) + exp(1) .* test_row(:, 5));
test_row_approx = test_row_approx + 1/exp(1) .* sqrt(test_row(:, 3))

% -2390.2515218200 + test_row_approx - 1 - max_error_row(11)

% max_error_row(11)
%% 


sprintf('%0.6f', max_error_row(4))


%% 

url = 'http://185.86.147.95/oracle?';
str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
coord = max_error_row(1:10)';

str = strcat(str1, string(coord));
str = strjoin(str,"&");
url = strcat(url, str)


%% 

string(fval_test(i, 4))
str2num(string(fval_test(i, 4)))

%% 

formatSpec = repmat("%d:%f", [1 10]);

formatSpec = strjoin(formatSpec," ");

fid = fopen('/Users/lmac/Documents/MATLAB/points');

A_orig = fscanf(fid,formatSpec);

fclose(fid);

%% 

A = A_orig(2:2:end);
A = reshape(A, 10, size(A, 1)/10); 
A = A';
%% 
fval_test = A;
f_approx = zeros(size(fval_test, 1), 1);
for i = 1:size(fval_test, 1)
    u = abs(resX4(:, 1) - fval_test(i, 4));
    [minu, minind] = min(u);
    f_approx(i) = resX4(minind, 2) - 1;
    if mod(i, 100) == 0
        disp(i);
    end
%     f_approx(i) = resX4(resX4(:, 1) == str2num(string(fval_test(i, 4))), 2) - 1;

end
%% 

f_approx = f_approx - fval_test(:, 2) .* fval_test(:, 7);
f_approx = f_approx + (fval_test(:, 9) .* sqrt(fval_test(:, 8)))./ (fval_test(:, 10) .* sqrt(fval_test(:, 7)));
f_approx = f_approx + log(exp(2) .* fval_test(:, 3) + exp(1) .* fval_test(:, 5));
f_approx = f_approx + 1/exp(1) .* sqrt(fval_test(:, 3));

%% 
M = 1:size(A, 1);
M = [M f_approx];

header = ["Id", "Expected"];
csvwrite('myFile.csv',header,0,0)
csvwrite('myFile.csv',M,1,0)

%% 

 u = abs(resX4(:, 1) - 2.069869e+00);
 [minu, minind] = min(u);
 f_approx = resX4(minind, 2) - 1;
f_approx
%% 

test_row = [7.053459e+00, 1.062090e-01, 6.704309e+00, 2.069869e+00, ...
       8.267119e+00, 5.835265e+00, 1.000000e-07, 3.852687e+00, ...
       2.420468e+00, 7.666253e+00];
% test_row = max_error_row;
test_row_approx = f_approx;
% test_row_approx = test_row_approx - test_row(:, 2) .* test_row(:, 7);
% test_row_approx = test_row_approx + (test_row(:, 9) .* sqrt(test_row(:, 8)))./ (test_row(:, 10) .* sqrt(test_row(:, 7)));
test_row_approx = test_row_approx + log(exp(2) .* test_row(:, 3) + exp(1) .* test_row(:, 5));
test_row_approx = test_row_approx + 1/exp(1) .* sqrt(test_row(:, 3))

%% 

3059973.7014097767 - test_row_approx


%% 
a = 1/(-test_row_approx + 8756.24349*2000)
%% 

err = (d^2 - (b^2 - a^2)*n)/(2*d)
oerr = 1/err
%% 
x7 = oerr.*(test_row(:, 9) .* sqrt(test_row(:, 8)))./test_row(:, 10);
x7 = x7^2

sprintf('%0.10f', x7)


%% 
b = 12382.61406;
a = 8756.24349; 
n = 4e6;
d = 17512329.671130188;
(d - (b^2 - a^2)*n/d)/2
(d^2 - (b^2 - a^2)*n)/(2*d)

%% 

    %% 
fval_test = dlmread('/Users/lmac/Documents/MATLAB/f_val.txt','');
%% 

f_approx = zeros(size(fval_test, 1), 1);
for i = 1:size(fval_test, 1)
    u = abs(resX4(:, 1) - str2num(string(fval_test(i, 4))));
    [minu, minind] = min(u);
    f_approx(i) = resX4(minind, 2) - 1;

%     f_approx(i) = resX4(resX4(:, 1) == str2num(string(fval_test(i, 4))), 2) - 1;

end
%% 

f_approx = f_approx - fval_test(:, 2) .* fval_test(:, 7);
f_approx = f_approx + (fval_test(:, 9) .* sqrt(fval_test(:, 8)))./ (fval_test(:, 10) .* sqrt(fval_test(:, 7)));
f_approx = f_approx + log(exp(2) .* fval_test(:, 3) + exp(1) .* fval_test(:, 5));
f_approx = f_approx + 1/exp(1) .* sqrt(fval_test(:, 3));

%% 

diff_f = fval_test(:, 11) - f_approx;

[res, n] = sumsqr(diff_f)

%% 

fval_x4 = dlmread('/Users/lmac/Documents/MATLAB/x4_predict.txt','');


%% 

formatSpec = repmat("%d:%f", [1 10]);

formatSpec = strjoin(formatSpec," ");

fid = fopen('/Users/lmac/Documents/MATLAB/points');

A_orig = fscanf(fid,formatSpec);

fclose(fid);

%% 

A = A_orig(2:2:end);
A = reshape(A, 10, size(A, 1)/10); 
A = A';
%% 
% fval_test = A;
% f_approx = zeros(size(fval_test, 1), 1);
% for i = 1:size(fval_test, 1)
%     u = abs(resX4(:, 1) - fval_test(i, 4));
%     [minu, minind] = min(u);
%     f_approx(i) = resX4(minind, 2) - 1;
%     if mod(i, 100) == 0
%         disp(i);
%     end
% %     f_approx(i) = resX4(resX4(:, 1) == str2num(string(fval_test(i, 4))), 2) - 1;
% 
% end
%% 
fval_test = A;
%% 

f_approx = fval_x4(:, 2);
f_approx = f_approx - fval_test(:, 2) .* fval_test(:, 7);
f_approx = f_approx + (fval_test(:, 9) .* sqrt(fval_test(:, 8)))./ (fval_test(:, 10) .* sqrt(fval_test(:, 7)));
f_approx = f_approx + log(exp(2) .* fval_test(:, 3) + exp(1) .* fval_test(:, 5));
f_approx = f_approx + 1/exp(1) .* sqrt(fval_test(:, 3));

%% 


sum(A(:, 4) - fval_x4(:, 1)) == 0

%% 

[maxf, maxind] = min(f_approx);
%% 

fval_test(maxind, :)
fval_test_orig(maxind, 11)
f_approx(maxind)


% fval_test(maxind, 7) = 1e-7;
%% 
filename = '/Users/lmac/Documents/MATLAB/matlab_cross_res';
fileID = fopen(filename, 'a+');

fprintf(fileID, '%f\n', f_approx);

fclose(fileID);
%% 

f_approx(488073) = 1497.2958880773606;

%% 

M = 1:size(A, 1);
M = [M' f_approx];

% header = ["Id", "Expected"];
% csvwrite('myFile.csv',header,0,0)
csvwrite('myFile.csv',M,1,0)

%% 

sprintf('%0.10f', pi/2)
%% 
x4t = 5.016800
1/sin(x4t + pi/2)
%% 
x4t = 1.720600
1/sin(x4t + pi/2) 
%% 
clear
fval_test = dlmread('/Users/lmac/Documents/MATLAB/f_val.txt','');
%% 

f_approx = 1./sin(fval_test(:, 4) + pi/2) - 1;
f_approx = f_approx - fval_test(:, 2) .* fval_test(:, 7);
f_approx = f_approx + (fval_test(:, 9) .* sqrt(fval_test(:, 8)))./ (fval_test(:, 10) .* sqrt(fval_test(:, 7)));
f_approx = f_approx + log(exp(2) .* fval_test(:, 3) + exp(1) .* fval_test(:, 5));
f_approx = f_approx + 1/exp(1) .* sqrt(fval_test(:, 3));

%% 

diff_f = fval_test(:, 11) - f_approx;

[res, n] = sumsqr(diff_f)


%% 
fval_test_orig = fval_test;
fval_test = string(fval_test(:, 1:10));

fval_test = str2double(fval_test);
%% 
fval_test2 = zeros(size(fval_test));

for i = 1:size(fval_test,1)
    fval_test2(i, :) = str2num(fval_test(i, :));
end
%% 

f_approx(1735018) - 3060022.30695

%% 

sprintf('%0.6f ', fval_test(1682053+1, :))
sprintf('%0.6f ', 5*pi/2)
%% 
f_approx(488073) = fval_pred(488073);
%% 
fval_pred = dlmread('/Users/lmac/Documents/MATLAB/all_predict.txt','');

%% 

fval_pred(488073)
%% 


diff = f_approx - fval_pred;

[res, n] = sumsqr(diff)

%% 

f_approx(488073) = 1491;



