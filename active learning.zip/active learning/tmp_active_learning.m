x = [1 exp(1) exp(2)]
y = [2.3678794412 3.6065393719 5.00000891202]
a = y(2) - y(1) - 1;
b = y(2) - y(3) + 1;

gamma = - a^2 / (a + b);

alfa = exp(y(1) - gamma);

yvar = (sqrt(gamma^2 - 4*gamma*b) + gamma)/(2*gamma);

beta = log(yvar);

log(alfa .* x) + gamma .* x .^ beta
log(exp(2) .*x) + 1/exp(1) .* sqrt(x)
y
%% 
fun = @funx3;
x0 = [1,1,1];
coef = fsolve(fun,x0)
%% 
1 / exp(1)


