function elem = bb_fun_elem(ind)
    nam = 11;
    url = 'http://185.86.147.95/oracle?';
    str1 = ["x1=";"x2=";"x3=";"x4=";"x5=";"x6=";"x7=";"x8=";"x9=";"x10="];
    coord = (ind - 1).*10./(nam - 1);
    str = strcat(str1, string(coord'));
    str = strjoin(str,"&"); 
    url = strcat(url, str);
    data = webread(url);
    display(coord')
    display(url)
    display(data)
    pattern1 = 'Function value = ';% start of list
    pattern2 = 'Attempts left =';  % end of list
    list = extractBetween(data, pattern1, pattern2);% extract list

    fun_value = str2double(list{1});
    
    filename = '/Users/lmac/Documents/MATLAB/f_val.txt';
    fileID = fopen(filename, 'a+');
    fprintf(fileID, strcat(repmat('%f ', [1 10]), ' %.10f\n'), [coord'; fun_value]');
    fclose(fileID);
    
    elem = fun_value; 
end