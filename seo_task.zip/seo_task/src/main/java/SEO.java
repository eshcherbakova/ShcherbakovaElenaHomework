import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.fs.FileSystem;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class SEO extends Configured implements Tool {
    public static void main(final String[] args) throws Exception {
        final int rc = ToolRunner.run(new SEO(), args);
        System.exit(rc);
    }

    @Override
    public int run(final String[] args) throws Exception {
        final FileSystem fs = FileSystem.get(getConf());
        if (fs.exists(new Path(args[1]))) {
            fs.delete(new Path(args[1]), true);
        }
        final Job job = getJobConf(args[0], args[1]);
        return job.waitForCompletion(true) ? 0 : 1;
    }

    public static class divideByHost extends Partitioner<HostQuery, IntWritable> {
        @Override
        public int getPartition(final HostQuery key, final IntWritable val, final int numPartitions) {
            return Math.abs(key.getHost().hashCode()) % numPartitions;
        }
    }

    public static class KeyComparator extends WritableComparator {
        protected KeyComparator() {
            super(HostQuery.class, true);
        }

        @Override
        public int compare(final WritableComparable first, final WritableComparable second) {
            return ((HostQuery) first).compareTo((HostQuery) second);
        }
    }

    public static class Grouper extends WritableComparator {
        protected Grouper() {
            super(HostQuery.class, true);
        }

        @Override
        public int compare(final WritableComparable first, final WritableComparable second) {
            final Text host_first = ((HostQuery) first).getHost();
            final Text host_second = ((HostQuery) second).getHost();
            return host_first.compareTo(host_second);
        }
    }

    public static class SEOMapper extends Mapper<LongWritable, Text, HostQuery, IntWritable> {
        URI uri;
        static final IntWritable one = new IntWritable(1);
        @Override
        protected void map(final LongWritable key, final Text value, final Context context)
                throws IOException, InterruptedException {
            final String[] lines = value.toString().split("\t");
            String host;
            try {
                uri = new URI(lines[1]);
                host = uri.getHost();
                host = host.startsWith("www.") ? host.substring(4) : host;
            } catch (final URISyntaxException | NullPointerException e) {
                context.getCounter("COMMON_COUNTERS", "Bad_URLs").increment(1);
                return;
            }
            final HostQuery composite_key = new HostQuery(host, lines[0]);
            context.write(composite_key, one);
        }
    }

    public static class SEOReducer extends Reducer<HostQuery, IntWritable, Text, IntWritable> {
        private int minClicks = 100;
        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            minClicks = context.getConfiguration().getInt("seo.minclicks", minClicks);
        }
        @Override
        protected void reduce(final HostQuery key, final Iterable<IntWritable> values, final Context context)
                throws IOException, InterruptedException {
            values.iterator().next().get();
            int sum = 1;
            int max_sum = 1;
            String best_fitting_query = key.getQuery().toString();
            String cur_query = key.getQuery().toString();
            for (final IntWritable ignored : values) {
                if (!cur_query.equals(key.getQuery().toString())) {
                    if (sum > max_sum) {
                        max_sum = sum;
                        best_fitting_query = cur_query;
                    }
                    cur_query = key.getQuery().toString();
                    sum = 0;
                }
                ++sum;
            }
            if (max_sum >= minClicks)
                context.write(new Text(key.getHost() + "\t" + best_fitting_query),
                        new IntWritable(max_sum));
        }
    }

    Job getJobConf(final String input, final String out_dir) throws IOException {
        final Job job = Job.getInstance(getConf());
        job.setJarByClass(SEO.class);
        job.setJobName(SEO.class.getCanonicalName());
        FileInputFormat.setInputDirRecursive(job, true);
        job.setInputFormatClass(TextInputFormat.class);
        FileInputFormat.addInputPath(job, new Path(input));
        FileOutputFormat.setOutputPath(job, new Path(out_dir));

        job.setMapperClass(SEOMapper.class);
        job.setReducerClass(SEOReducer.class);

        job.setPartitionerClass(divideByHost.class);
        job.setSortComparatorClass(KeyComparator.class);
        job.setGroupingComparatorClass(Grouper.class);

        job.setMapOutputKeyClass(HostQuery.class);
        job.setMapOutputValueClass(IntWritable.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        return job;
    }
}

