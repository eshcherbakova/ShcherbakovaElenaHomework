import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.JobContext;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.EOFException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;

public class pkzInputFormat extends FileInputFormat<LongWritable, Text> {
    public static class pkzFileSplit extends FileSplit {
        private List<Integer> documents_sizes_list;

        public pkzFileSplit() {
            super();
        }

        public pkzFileSplit(Path file, long start, long split_len, List<Integer> doc_sizes) {
            super(file, start, split_len, new String[]{});
            documents_sizes_list = new ArrayList<>(doc_sizes);
        }

        @Override
        public void write(DataOutput out) throws IOException {
            super.write(out);

            out.writeInt(documents_sizes_list.size());
            for (Integer cur_size : documents_sizes_list) {
                out.writeInt(cur_size);
            }
        }

        @Override
        public void readFields(DataInput in) throws IOException {
            super.readFields(in);

            documents_sizes_list = new ArrayList<>();
            for (int number_of_sizes = in.readInt(); number_of_sizes > 0; number_of_sizes--) {
                documents_sizes_list.add(in.readInt());
            }
        }

        public List<Integer> getDocumentSizesList() {
            return documents_sizes_list;
        }
    }

    public static class pkzRecordReader extends RecordReader<LongWritable, Text> {
        private FSDataInputStream input_stream;
        private Integer current_offset = 0;
        private List<Integer> documents_sizes_list;
        private int current_document = 0;
        private Text current_document_text = new Text();

        private final Log LOG = LogFactory.getLog(pkzRecordReader.class);
        private final int MAX_BUFFER_SIZE = 2048;

        @Override
        public void initialize(InputSplit split, TaskAttemptContext context) throws IOException {
            Configuration conf = context.getConfiguration();
            pkzFileSplit pkz_split = (pkzFileSplit) split;
            documents_sizes_list = pkz_split.getDocumentSizesList();

            Path path = pkz_split.getPath();
            FileSystem fs = path.getFileSystem(conf);
            input_stream = fs.open(path);
            current_offset = (int) pkz_split.getStart();
            input_stream.seek(current_offset);
        }

        @Override
        public boolean nextKeyValue() throws IOException {
            if (current_document >= documents_sizes_list.size()) {
                current_document_text = new Text();
                return false;
            }

            int document_size = documents_sizes_list.get(current_document);
            byte[] bytes = new byte[document_size];
            input_stream.readFully(bytes, 0, document_size);

            current_document_text = new Text();
            Inflater decompressor = new Inflater();
            decompressor.setInput(bytes);

            byte[] decompression_buffer = new byte[MAX_BUFFER_SIZE];
            while (true) {
                try {
                    int len_read = decompressor.inflate(decompression_buffer);
                    if (len_read > 0) {
                        current_document_text.append(decompression_buffer, 0, len_read);
                    } else {
                        break;
                    }
                } catch (DataFormatException err) {
                    LOG.warn("Cannot decompress document with offset " + current_offset);
                    break;
                }
            }
            decompressor.end();

            current_document++;
            current_offset += document_size;
            return true;
        }

        @Override
        public LongWritable getCurrentKey() {
            return new LongWritable(current_offset);
        }

        @Override
        public Text getCurrentValue() {
            return current_document_text;
        }

        @Override
        public float getProgress() {
            return (float) current_document / documents_sizes_list.size();
        }

        @Override
        public void close() {
            IOUtils.closeStream(input_stream);
        }
    }

    @Override
    public pkzRecordReader createRecordReader(InputSplit split, TaskAttemptContext context) throws IOException {
        pkzRecordReader reader = new pkzRecordReader();
        reader.initialize(split, context);
        return reader;
    }

    @Override
    public List<InputSplit> getSplits(JobContext context) throws IOException {
        Configuration conf = context.getConfiguration();
        List<InputSplit> splits = new ArrayList<>();

        for (FileStatus status: listStatus(context)) {
            Path file_path = status.getPath();
            Path file_index_path = file_path.suffix(".idx");
            FileSystem fs = file_path.getFileSystem(conf);
            FSDataInputStream index_file = fs.open(file_index_path);

            long split_offset = 0;
            long split_size = 0;
            ArrayList<Integer> documents_in_split_sizes = new ArrayList<>();
            while (true) {
                int size_of_document = 0;
                try {
                    size_of_document = Integer.reverseBytes(index_file.readInt());
                } catch (EOFException exc) {
                    break;
                }

                split_size += (long) size_of_document;
                documents_in_split_sizes.add(size_of_document);
                if (split_size >= getNumBytesPerSplit(conf)) {
                    splits.add(new pkzFileSplit(file_path, split_offset, split_size,
                            documents_in_split_sizes));
                    split_offset += split_size;
                    split_size = 0;
                    documents_in_split_sizes.clear();
                }
            }
            if (!documents_in_split_sizes.isEmpty()) {
                splits.add(new pkzFileSplit(file_path, split_offset, split_size,
                        documents_in_split_sizes));
            }

            index_file.close();
        }

        return splits;
    }

    public static final String BYTES_PER_MAP_PARAMETER = "mapreduce.input.indexedgz.bytespermap";
    public static long getNumBytesPerSplit(Configuration conf) {
        return conf.getLong(BYTES_PER_MAP_PARAMETER, 32L * 1024L * 1024L);
    }
}
